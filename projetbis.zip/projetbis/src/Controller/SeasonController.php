<?php

namespace App\Controller;

use App\Entity\Season;
use App\Entity\Series;
use App\Entity\Episode;
use App\Form\SeasonType;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/seasons')]
class SeasonController extends AbstractController
{

    /*
    #[Route('/', name: 'season_index', methods: ['GET'])]
    public function index(EntityManagerInterface $entityManager, Series $serie, int $season_number): Response
    {
        return $this->render('season/index.html.twig');
    }*/



    #[Route('/{serie}/{number}', name: 'season_show', methods: ['GET'])]
    public function show(Series $serie, int $number, EntityManagerInterface $entityManager): Response
    {
        $season = $entityManager
            ->getRepository(Season::class)
            ->findBy([
                'series' => $serie,
                'number' => $number
            ])[0];

        $episodes = $entityManager
            ->getRepository(Episode::class)
            ->findBy(['season' => $season], array('number' => 'ASC'));

        return $this->render('season/show.html.twig', [
            'serie' => $serie,
            'season' => $season,
            'episodes' => $episodes
        ]);
    }

    /**
     * A voir pour l'admin
     */

    /*
    #[Route('/{id}/edit', name: 'season_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Season $season, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(SeasonType::class, $season);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('season_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('season/edit.html.twig', [
            'season' => $season,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'season_delete', methods: ['POST'])]
    public function delete(Request $request, Season $season, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $season->getId(), $request->request->get('_token'))) {
            $entityManager->remove($season);
            $entityManager->flush();
        }

        return $this->redirectToRoute('season_index', [], Response::HTTP_SEE_OTHER);
    }

    #[Route('/new', name: 'season_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $season = new Season();
        $form = $this->createForm(SeasonType::class, $season);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($season);
            $entityManager->flush();

            return $this->redirectToRoute('season_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('season/new.html.twig', [
            'season' => $season,
            'form' => $form,
        ]);
    }*/
}
