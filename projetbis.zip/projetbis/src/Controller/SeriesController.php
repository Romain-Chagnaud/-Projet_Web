<?php

namespace App\Controller;

use App\Entity\Episode;
use App\Entity\Season;
use App\Entity\Series;
use App\Entity\User;
use App\Form\SeriesType;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Mapping\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/series')]
class SeriesController extends AbstractController
{
    #[Route('/all/{page}', name: 'series', methods: ['GET'])]
    public function series(EntityManagerInterface $entityManager, int $page): Response
    {
        $series = $entityManager
            ->getRepository(Series::class)
            ->findBy(array(), array('title' => 'ASC'));

        return $this->render('series/index.html.twig', [
            'series' => $series,
            'page' => $page
        ]);
    }

    #[Route('/search/{page}', name: 'series_search', methods: ['GET'])]
    public function series_search(EntityManagerInterface $entityManager, int $page, string $search): Response
    {
        $query = $entityManager->createQuery(
            "SELECT s
            FROM App\Entity\Series s
            WHERE s.title LIKE :search
            ORDER BY s.title ASC"
        )->setParameter('search', '%' . $search . '%');
        $series = $query->getResult();

        return $this->render('series/search.html.twig', [
            'series' => $series,
            'page' => $page,
            'search' => $search
        ]);
    }

    #[Route('/follow/{serie}', name: 'series_follow', methods: ['GET'])]
    public function follow(Series $serie, EntityManagerInterface $entityManager): Response
    {
        $user = $this->getUser();
        $user->addSeries($serie);
        $entityManager->flush();

        
        return $this->show($serie);
    }


    #[Route('/new', name: 'series_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $serie = new Series();
        $form = $this->createForm(SeriesType::class, $serie);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($serie);
            $entityManager->flush();

            return $this->redirectToRoute('series_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('series/new.html.twig', [
            'series' => $serie,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'series_show', methods: ['GET'])]
    public function show(Series $serie): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $query = $entityManager->createQuery('SELECT s
        FROM App:Season s
        WHERE s.series = ' . $serie->getId() .
            "ORDER BY s.number");

        $seasons = $query->getResult();

        return $this->render('series/show.html.twig', [
            'serie' => $serie,
            'seasons' => $seasons
        ]);
    }

    #[Route('/{id}/poster', name: 'series_poster', methods: ['GET'])]
    public function poster(Series $serie): Response
    {
        return new Response(stream_get_contents($serie->getPoster()), 200, array('Content-type' => 'image/jpeg'));
    }


    #[Route('/{id}/edit', name: 'series_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Series $serie, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(SeriesType::class, $serie);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('series_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('series/edit.html.twig', [
            'serie' => $serie,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'series_delete', methods: ['POST'])]
    public function delete(Request $request, Series $serie, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $serie->getId(), $request->request->get('_token'))) {
            $entityManager->remove($serie);
            $entityManager->flush();
        }

        return $this->redirectToRoute('series_index', [], Response::HTTP_SEE_OTHER);
    }
}
