<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/account')]
class AccountController extends AbstractController
{    

    #[Route('/', name: 'account')]
    public function account(): Response
    {
        return $this->render('account/index.html.twig');
    }
    #[Route('/series', name: 'my_series')]
    public function followed_series(): Response
    {
        return $this->render('account/series.html.twig');
    }

}
